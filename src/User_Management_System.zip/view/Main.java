package view;

import controller.UserManagement;

public class Main {
    public static void main(String[] args) {
        UserManagement userManagement = new UserManagement();
        userManagement.run();
    }
}
